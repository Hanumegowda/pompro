package com.qsgsoft.com.qsgsoft.com.EMResourcesNew;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
