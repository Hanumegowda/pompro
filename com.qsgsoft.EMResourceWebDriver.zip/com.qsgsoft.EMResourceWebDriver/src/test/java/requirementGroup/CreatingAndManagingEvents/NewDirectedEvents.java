package requirementGroup.CreatingAndManagingEvents;

import qaframework.lib.testngExtensions.TestNG_UI_EXTENSIONS;

public class NewDirectedEvents extends TestNG_UI_EXTENSIONS{

	public NewDirectedEvents() throws Exception {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
