package lib.dataObject;

public class Upload_data {

	public final String strUploadResFile_Path = "UploadResFile_Path",
						strRow = "1",
						strYesOrNoValue = "No",
						strGeoCodeValue = "No",
						strEmptyGeoCodeVal   = " ",
						strExcelName = "ImportResource.xls",
						strInvalidResourceTypeID = "invalid ResourceTypeID",
						strYesValue="Yes",
						strNoResComment="no resource data provided",
						strUserComments="duplicate UserID",
						strUserComments2="duplicates user in row 3",
						strRow2 = "2",
						strRow3 = "3",
						strRow4 = "4",
						strResComment="existing resource";
}
