package lib.dataObject;

import qaframework.lib.UserDefinedFunctions.Date_Time_settings;

public class ResourceType_data {

	Date_Time_settings objDate_Time_settings = new Date_Time_settings();
	String strTimeText = objDate_Time_settings.getCurrentDate("MM-dd-yyyy-hhmmss");

	public String strResTypeDescription = "Automation",
			      strResourceTypeName = "RT" + strTimeText,
			      strResourceTypeName1 = "RT1" + strTimeText,
			      strResourceTypeName2 = "RT2" + strTimeText,
			      strSubResStatus = "Yes",
			      strSubResourceTypeName = "SRT"+strTimeText,
			      strSubResourceTypeName1 = "SRT1"+strTimeText,
			      strEdResourceTypeName = "EdRT"+strTimeText,
			      strEdResTypeDescription = "EdAutomation",
			      strSubResNoStatus = "No",
			      strResourceTypeName3 = "RT3" + strTimeText;

}
