package lib.dataObject;

import qaframework.lib.UserDefinedFunctions.Date_Time_settings;

public class View_data {
	
	Date_Time_settings objDate_Time_settings = new Date_Time_settings();
	String strTimeText = objDate_Time_settings.getCurrentDate("MM/dd/yyyy-hhmmss");
	String strDate = objDate_Time_settings.getCurrentDate("MM/dd/yyyy");
	String strFutureDate = objDate_Time_settings.getFutureDay(3, "MM/dd/yyyy");
	String strFutureDate1 = objDate_Time_settings.getFutureDay(2, "MM/dd/yyyy");
	String strPasteDate = objDate_Time_settings.getFutureDay(-3, "MM/dd/yyyy");
	
	public String strViewName = "View" + System.currentTimeMillis(),
				  strViewName2 = "View2"+ System.currentTimeMillis(),
				  strViewDesc = "ViewDesc" + System.currentTimeMillis(),
				  strValueForUpdate = "1",
				  strValueForUpdate1 = "2",
				  strMap = "Map",
				  strSectionName = "Section" + System.currentTimeMillis(),
				  strSectionName1 = "Section1" + System.currentTimeMillis(),
				  strSectionName2 = "Section2" + System.currentTimeMillis(),
				  strEditedSectionName = "ESection" + System.currentTimeMillis(),
				  strCustomView = "Custom"+ strTimeText,
				  strCustomView1 = "Custom1"+ strTimeText,
				  strValueForTST = "testings",
				  strUpdatedValForSST = "429",
				  strUpdatedValForSST1 = "483",
				  strUpdatedValForNDST = "2401",
				  strNEDOCValue = "241 - Disaster",
				  strAboveValueForUpdate = "112",
			      strAboveValueForUpdate1 = "115",
				  strDateUpdateValue = strDate,
				  strDateUpdateFutureValue = strFutureDate,
				  strVal = "2220",
				  strNEDOCVal = "241",
				  strRegionDefaultName = "Region Default (default)",
				  strRegionDefault = "Region Default",
				  strValueForTST1 = "UpdatedTST",
				  strZeroValue = "N/A",
				  strSummaryTable = "Status Type Summary",
				  strStatusTypeSummary = "Status Type Summary",
				  strTotal = "Total",
				  strSummaryPlus = "Summary Plus (Resources as rows. Status types and comments as columns.)",
				  strSummary = "Summary (Resources as rows. Status types as columns.)",
				  strResource = "Resource (Resources and status types as rows. Status, comments and timestamps as columns.)",
				  strHybrid = "Hybrid (Enables each resource type (section) to display in any of the view types.)",
				  strNEDOCValue1 = "406",
				  strDateUpdatePastValue=strPasteDate ,
				  strCustom = "Custom",
				  strNDSTValInExcel = "Disaster",
				  strComment = "Comment",
				  strComment1 = "Comment1",
				  strComment2 = "Comment2",
				  strComment3 = "Comment3",
				  strComment4 = "Comment4",
				  strComment5 = "Comment5",
				  strNotApplicable = "N/A",
				  strValueForUpdate2 = "3",
				  strValueForTST2 = "secondUpdatedTST",
				  strValueForTST3 = "thirdUpdatedTST",
				  strNEDOCValue2 = "406 - Disaster",
				  strUpdatedValForSST2 = "700",
				  strUpdatedValForSST3 = "900",
				  strEditedViewName = "EditedView"+ System.currentTimeMillis(),
				  strEditedViewDesc = "EditedViewDesc" + System.currentTimeMillis(),
				  strViewName3 = "View3" + System.currentTimeMillis(),
				  strAboveValueForUpdate2 = "200",
				  strAboveValueForUpdate3 = "700",
				  strNEDOCValue3 = "325 - Disaster",
				  strDateUpdateFutureValue1 = strFutureDate1,
				  strNEDOCValue4 = "325",
				  strHyphen = "--",
				  strNEDOCValueInUpdateScreen = "241-Disaster",
				  strZero = "0",
				  strNEDOCValue5 = "706 - Disaster",
				  strNEDOCValue6 = "726 - Disaster",
				  strNEDOCValue7 = "686 - Disaster",
				  strRegionDefaultMyDefault = "Region Default (my default)";
	
	
	public String[] strValueForSST	= {"1", "2", "3", "4", "5", "6", "7", "8", "9"},
					strValueForNDST	= {"1", "2", "3", "4", "5", "6", "7"},
					strValueForSST1 = {"2", "3", "4", "5", "6", "7", "8", "9", "9"},
					strValueForNDST1 = {"3", "1", "4", "5", "8", "2", "3"},
					strValueForSST2 = {"1", "1", "1", "1", "1", "1", "1", "1", "1"},
					strValueForSST3 = {"5", "9", "4", "8", "3", "7", "2", "6", "1"},
					strValueForNDST2 = {"2", "3", "4", "5", "6", "7", "8"},
					strValueForNDST5 = {"2", "2", "2", "2", "2", "2", "2"},
					strValueForNDST6 = {"3", "3", "3", "3", "3", "3", "3"},
					strValueForNDST7 = {"1", "1", "1", "1", "1", "1", "1"};
	
	public int strDefaultCount = 0;
	
}
