package lib.dataObject;


public class UpdateStatus_data {


	public String strNSTUpdateValue = "2",
			strTSTUpdateValue = "Test";
	public String[] strSSTUpdateValue= { "0", "1", "2", "3", "4", "5", "6",
			"7", "8" },
			strNDSTUpdateValue = {  "1", "2", "3", "4", "5", "6",
					"7", "8","9"};                
}