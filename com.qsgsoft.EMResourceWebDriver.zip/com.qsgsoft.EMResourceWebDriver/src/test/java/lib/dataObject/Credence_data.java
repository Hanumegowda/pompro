package lib.dataObject;

public class Credence_data {
	
	public String strLinkToCoresDots = "CORES DOTS",
			      strEMResource = "EMResource";

}
