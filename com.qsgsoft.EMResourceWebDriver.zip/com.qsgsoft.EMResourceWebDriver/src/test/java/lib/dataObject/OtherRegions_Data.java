package lib.dataObject;

public class OtherRegions_Data {
	
	public String strFacilityName = "Liberty Hospital - TC";

}
