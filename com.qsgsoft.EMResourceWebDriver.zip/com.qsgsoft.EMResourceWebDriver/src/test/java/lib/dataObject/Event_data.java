package lib.dataObject;

import qaframework.lib.UserDefinedFunctions.Date_Time_settings;

public class Event_data {

	Date_Time_settings objDate_Time_settings = new Date_Time_settings();
	String strTimeText = objDate_Time_settings
			.getCurrentDate("MM-dd-yyyy-hhmmss");

	public String strEventName = "Event" + strTimeText,
			strEventDescription = "Automation",
			strEventStartTime = "",
			strEventEndTime = "",
			strNullEventName = "",
			strEventEndTimeInHours = "5",
			strAdHocEventTempName = "Ad Hoc Event",
			strEventName1 = "Event1" + strTimeText,
			strEventName2 = "Event2" + strTimeText,
			strEventEndTimeInHours1 = "4",
			strEventEndTime1 = "",
			strGetEventStartTime = "",
			strEventEndDescription = "Event ended.",
			strEditedEventName = "EdEvent" + strTimeText,
			strEditedEventDescription = "EdAutomation",
			strFuture = "Future",
			strOngoing = "Ongoing",
			strEnded = "Ended",
			strMultiRegionEvent = "MultiEvent" + strTimeText,
			strMultiRegionEventDescription = "MultiAutomation",
			strNo = "No",
			strNumber = "4",
			strViewHistoryAction = "View�History",
			strNotParticipating = "-- Not Participating --",
			strCity = "City",
			strState = "Delaware",
			strZipcode = "12345",
			strCounty = "Kent County",
			strCountryCode = "DE",
			endDateForNeverEndEvent = "31 Dec 2999 00:00. ",
			strViewAction = "View",
			strEveAmbulanceIconVal = "/icon/event43.png",
			strEndNever = "never",
			strAttachedFileText = "File to be uploaded",
			strAttachedHTMLText = "Test EMResource Events",
			strAttachedPDFText = "Automation Event",
			strUpdateEventName = "Update 1: " + strEventName,
			strUpdateEventName1 = "Update 2: " + strEventName,
			strUpdatedEditEventName = "Update 1: " + strEditedEventName,
			strNoneET = "- None -",
			strNone = "- None -",
			strAutomaticShchedulingsys = "EMResource Automated Scheduling System",
			strEventName3 = "Event3" + strTimeText,
			strYes = "Yes";
	public String[] strEventHeaders = { "Action", "Icon", "Multi?", "Status",
			"Start", "End", "Title", "Drill", "Template", "Information" };
}
