package lib.dataObject;

public class CORES_data {
	
	public String strCoresUserName = "CoresAuto"+System.currentTimeMillis(),
            strCoresPassword = "abc123",
            strFirstName = "FN",
            strLastName = "LN",
            strSecretQuestion = "What is the name of your first school?",
            strSecretAnswer = "School",
            strAddressLine = "Address 1",
            strCity = "Bangalore",
            strState = "Arizona",
            strZipcode = "12345",
            strContactMethod = "Mobile Phone",
            strNumberToAttempt1 = "888",
    		strNumberToAttempt2 = "888",
			strNumberToAttempt3 = "8888",
			strOccupation = "Accountant",
			strOccupationType = "Non-Medical",
			strStatusForOccupation = "Active";
}
