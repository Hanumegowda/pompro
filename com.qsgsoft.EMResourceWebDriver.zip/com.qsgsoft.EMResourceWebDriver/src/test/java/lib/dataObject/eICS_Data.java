package lib.dataObject;

import qaframework.lib.UserDefinedFunctions.Date_Time_settings;

public class eICS_Data {
	
	Date_Time_settings objDate_Time_settings = new Date_Time_settings();
	String strTimeText = objDate_Time_settings.getCurrentDate("MM/dd/yyyy-hhmmss");
	
	public String strExistingResourceNameForEICS = "Freeman West",
		          streICSRegName = "Freeman West",
		          strIRGName = "TEST #1",
		          strIncidentName = "Inc"+ strTimeText,
		          strIncidentName2 = "Inc2"+ strTimeText,
		          strIncidentName3 = "Inc3"+ strTimeText,
		          strIncidentDesc = "DrillDescription",
		          strIconName = "/icon/eventics.png",
		          strContactName = "Cont"+  System.currentTimeMillis(),
		          strContactUserId = "AutoCont"+ System.currentTimeMillis(),
		      	  strMidName = "MN",
		   		  strLastName = "LN",
		   		  strPhNo = "5555551234",
		   		  strEmailID = "autoemr_1@qsgsoft.com",
		   		  strPosition = "Liaison Officer",
		   		  strFacilityName = "Liberty Hospital",
		          strIRGName1 = "Fire - Code Red",
		          strPosition1 = "Safety Officer",
		          strContactName1 = "Cont1"+  System.currentTimeMillis(),
		          strContactUserId1 = "AutoCont1"+ System.currentTimeMillis(),
		          strExistingResourceTypeNameForEICS= "Region D Hospitals",
		          strExistingResourceNameForEICS1 = "Freeman West (MHA)",
		          strExistingResourceNameForEICS2 = "Liberty Hospital - TC",
		          strExistingResourceNameInEICS2 = "Liberty Hospital",		          
		          strExistingResourceNameForEICS3 = "North Kansas City Hospital - TC",
		          strExistingResourceNameInEICS3 = "North Kansas City Hospital",
		          strExistingResNameForEICSCoxNorth = "Cox North",
		          strExistingResNameInEICSCoxNorth = "CoxNorth",
		          strExistingResourceNameForEICSBartonCounty = "Barton County Memorial Hospital",
		          strBartonCountyMem = "Barton County Mem", 
		          strEarthquake= "Earthquake";
	
}
