package lib.dataObject;

import qaframework.lib.UserDefinedFunctions.Date_Time_settings;

public class Roles_data {
	
	Date_Time_settings objDate_Time_settings = new Date_Time_settings();
	String strTimeText = objDate_Time_settings.getCurrentDate("MM/dd/yyyy-hhmmss");
	
	public String strRoleName = "Role" +strTimeText,
			      strRoleName1 = "Role1" +strTimeText,
			      strRoleName2 = "Role2" +strTimeText,
			      strHelpDeskRole = "HelpDesk",
			      strSystemAdminRole = "SystemAdmin";
}
