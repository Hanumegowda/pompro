package lib.dataObject;

public class NotificationValues {

	public String strAboveVal = "50",
				  strBelowVal = "100",
				  strEdAboveVal = "200",
				  strEdBelowVal = "100",
				  strAboveValForSST = "480",
				  strBelowValForSST = "430",
				  strEdAboveValForSST = "800",
				  strEdBelowValForSST = "300",
				  strAboveValueForNDSt="180",
				  strBelowValueForNDSt="0";
				  
}
